#!/usr/bin/perl
use warnings;
use strict;
use Data::Dumper;

# ******************************************************************************
#
# Expand MCx baseband I/Q calibration data for shared sites
#
# Usage: expand_bbiq_data.pl <pinconfig> <calfile> <outfile>
#
# V 0.1 / Feb 03, 2016
#   
# ******************************************************************************


#
# Analyze pin configuration
#
# Input: Pin configuration data from file (ref)
#
# Returns: Hash of configured sites (ref)
# Key 1: Pin
# Key 2: Site
# $VAR1 = 'BB_RXI';
# $VAR2 = {
#           '4' => 'MCE231:10',
#           '1' => 'MCE231:9',
#           '3' => 'MCE231:10',
#           '2' => 'MCE231:9'
#         };
#
sub get_configured_sites
{
    my $configdata = shift;
    my %configured_sites;

    my $separator = qr/[ ,\"\(\)]+/;

    foreach (@$configdata) {
        if (/^DFAN \"MC[BE][\d]{3}/) {
            my ($cmd, $board, $pin, $mode, $name) = split $separator;
            $configured_sites{$name}{1} = "$board:$pin";
        }
        if (/^PALS [\d]+,\"MC[BE][\d]{3}/) {
            my ($cmd, $site, $board, $pin, $mode, $name) = split $separator;
            $configured_sites{$name}{$site} = "$board:$pin";
        }
    }
    return \%configured_sites;
}


#
# Invert configuration info, so we can look up all sites for each resource
#
# Input: Hash of configured sites (ref)
#
# Returns: Hash of equivalent sites (ref)
# These sites belong to the same resource.
# They can share the same calibration data.
# Key 1: Pin
# Key 2: Resource
# $VAR1 = 'BB_RXI';
# $VAR2 = {
#           'MCE231:9' => {
#                           '1' => '',
#                           '2' => ''
#                         },
#           'MCE231:10' => {
#                            '4' => '',
#                            '3' => ''
#                          }
#         };
#
sub get_equivalent_sites
{
    my $configured_sites = shift;
    my %equivalent_sites;

    while (my ($pin, $sites) = each %$configured_sites) {
        while (my ($site, $resource) = each %$sites) {
            $equivalent_sites{$pin}{$resource}{$site} = '';
        }
    }
    return \%equivalent_sites;
}


#
# Analyze calibration data for calibrated sites
#
# Input: Calibration data from file (ref)
#
# Returns: Hash of calibrated sites (ref)
# Key 1: "I" pin of IQ pair.
# $VAR1 = 'BB_RXI';
# $VAR2 = {
#           '1' => '',
#           '3' => ''
#         };
#
sub get_calibrated_sites
{
    my $caldata = shift;
    my %calibrated_sites;

    foreach (@$caldata) {
        my @fields = split /[ ,\"\(\)]+/;
        if ($fields[1] eq "SRCR") {
            my ($site, $ipin, $qpin) = @fields[4, 12, 13];
            $calibrated_sites{$ipin}{$site} = '';
            $calibrated_sites{$qpin}{$site} = '';
        }
    }
    return \%calibrated_sites;
}


#
# Identify shared sites that are not included in the calibration data
#
# Input: Hash of calibrated sites (ref)
#        Hash of equivalent sites (ref)
#
# Returns: Hash of remaining sites (ref)
# We will later duplicate the calibration data for these sites.
# Key 1: Pin
# Key 2: Calibrated site
# $VAR1 = 'BB_RXI';
# $VAR2 = {
#           '1' => {
#                    '2' => ''
#                  },
#           '3' => {
#                    '4' => ''
#                  }
#         };
#
sub get_remaining_sites
{
    my ($calibrated_sites, $equivalent_sites) = @_;
    my %remaining_sites;

    while (my ($calpin, $calsites) = each %$calibrated_sites) {
        while (my $calsite = each %$calsites) {
            while (my ($resource, $eqsites) = each %{$equivalent_sites->{$calpin}}) {
                if (exists $eqsites->{$calsite}) {
                    $remaining_sites{$calpin}{$calsite} = { %$eqsites };
                    delete $remaining_sites{$calpin}{$calsite}{$calsite};
                }
            }
        }
    }
    return \%remaining_sites;
}


#
# Duplicate calibration data for shared sites
#
# Input: Original calibration data from file (ref)
#        Hash of remaining sites (ref)
#
# Returns: Calibration data for shared sites
# We will later appended these to the original data.
#
sub get_caldata_supplement
{
    my ($caldata, $remaining_sites) = @_;
    my @caldata_supplement;

    foreach (@$caldata) {
        my @fields = split ',';
        if ($fields[0] eq "ACMD \"SRCR\"") {
            my $calsite = $fields[3];
            (my $calpin = $fields[11]) =~ s:\(::g;  # use "I" pin of IQ pair
            foreach my $addsite (sort keys %{$remaining_sites->{$calpin}{$calsite}}) {
                $fields[3] = $addsite;
                push @caldata_supplement, join(',', @fields);
            }
        }
    }
    return \@caldata_supplement;
}


#
# Main Program
#
# Command line arguments:
#   $1: Pin configuration file
#   $2: Original Baseband I/Q calibration file
#   $3: Output file for converted data
#
die "Usage: $0 <pinconfig> <calfile> <outfile>\n"
    unless @ARGV == 3;
my ($pinconfig, $calfile, $outfile) = @ARGV;

#
# Open logfile
#
open LOGFILE, ">$outfile.log";
my $cmd = `readlink -f $0`;
chomp $cmd;
print LOGFILE "Log for $cmd ", (join " ", @ARGV), "\n";
print LOGFILE "Date: ", `date -R`;
print LOGFILE "Host: ", `uname -nr`;
print LOGFILE "User: ", `whoami`;

#
# Read pin configuration file
#
open PINCONFIG, $pinconfig or die "Error: Can't open file '$pinconfig': $!\n";
my @configdata = <PINCONFIG>;
close PINCONFIG;

#
# Analyze configured sites
#
my $configured_sites = get_configured_sites(\@configdata);
die "Error: No pin configuration data found in file '$pinconfig'\n"
    unless %$configured_sites;
print LOGFILE "Configured Sites:\n";
print LOGFILE Dumper(%$configured_sites);

my $equivalent_sites = get_equivalent_sites($configured_sites);
print LOGFILE "Equivalent Sites:\n";
print LOGFILE Dumper(%$equivalent_sites);

#
# Read calibration file
#
open CALFILE, $calfile or die "Error: Can't open file '$calfile': $!\n";
my @caldata = <CALFILE>;
close CALFILE;
die "Error: File '$calfile' is not a valid baseband I/Q calibration file\n"
    unless $caldata[0] =~ /^hp93000,board_skew_cal/;

#
# Log header info
#
print LOGFILE "Cal data header:\n";
foreach (@caldata) {
    last if /^ACMD/;
    print LOGFILE;
}

#
# Analyze calibration data
#
my $calibrated_sites = get_calibrated_sites(\@caldata);
print LOGFILE "Calibrated Sites:\n";
print LOGFILE Dumper(%$calibrated_sites);

my $remaining_sites = get_remaining_sites($calibrated_sites, $equivalent_sites);
print LOGFILE "Remaining Sites:\n";
print LOGFILE Dumper(%$remaining_sites);

#
# Duplicate calibration data for shared sites
#
my $caldata_supplement = get_caldata_supplement(\@caldata, $remaining_sites);

#
# Write new calibration file with shared site data
#
die "Error: Can't use same file for input and output\n"
    if $outfile eq $calfile;
open OUTFILE, ">$outfile" or die "Error: Can't open file '$outfile' for writing: $!\n";
print OUTFILE @caldata, @$caldata_supplement;
close OUTFILE;

#
# OK
#
print "Conversion successful\n";
print "Output written to file '$outfile'\n";
print LOGFILE "*** SUCCESS ***\n";
close LOGFILE;
